package com.exercise1.bowen.dai;



public class Question1<E> {
	public static void main(String[] args) {
		PositionalList<Integer> L = new LinkedPositionalList<Integer>(); 
		L.addFirst(7); 			
		L.addFirst(8); 			
		L.addLast(9); 				
		
		Position <Integer> pFirst = L.first(); 
		Position <Integer> pLast = L.last();   
		
		L.addFirst(32); 			
		L.addFirst(3);				
		L.addBefore(pFirst, 1);	
		L.addBefore(pFirst, 2);	
		L.addBefore(pFirst, 3); 	
		L.addAfter(pFirst, 4); 	
		
		System.out.println(L); 
		System.out.println("First position = " + pFirst.getElement()); 
		System.out.println("last position = " + pLast.getElement());
		System.out.println("Index of position: "+ L.indexOf(pFirst));

	}

}
