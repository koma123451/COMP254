package com.exercise2.bowen.dai;
import java.util.Stack;
public class Question2 {
	public static void transfer(Stack<Integer> S, Stack<Integer> T)
	{
		while(!S.isEmpty())
		{
			int temp = S.pop();
			T.push(temp);
		}
	}
	public static void main(String[] args)
	{
		Stack<Integer> S = new Stack<Integer>();
		Stack<Integer> T = new Stack<Integer>();
		S.push(6);
		S.push(4);
		S.push(7);
		S.push(1);
		S.push(2);
		S.push(3);
		transfer(S, T);
		System.out.println("Contents of T after transfer is: ");
		while( !T.isEmpty() )
			System.out.println(T.pop());
	}
}
