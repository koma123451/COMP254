package com.exercise3.bowen.dai;

public class LinkedQueue<E> implements Queue<E> {

/** The primary storage for elements of the queue */

private SinglyLinkedList<E> list = new SinglyLinkedList<>(); // an empty list

/** Constructs an initially empty queue. */

public LinkedQueue() {

} 


public int size() {

return list.size();

}

public boolean isEmpty() {

return list.isEmpty();

}

public void enqueue(E element) {

list.addLast(element);

}

public E first() {

return list.first();

}


public E dequeue() {

return list.removeFirst();

}



public String toString() {

return list.toString();

}

void concatenate(LinkedQueue<E> Q2) {

if (list == null)

list = Q2.list;

else {

while (!Q2.isEmpty()) {

list.addLast(Q2.dequeue());

}

}

}

}