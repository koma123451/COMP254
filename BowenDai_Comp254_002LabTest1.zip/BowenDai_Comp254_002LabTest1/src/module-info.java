module BowenDai_Comp254_002LabTest1 {
}