package com.question2.bowen.dai;


class Node 
{
	int data;
	Node next, prev;
	Node(int d)
	{
		data = d;
		next = prev = null;
	}
}

class DoubleLinkedList 
{
	Node head, tail;
    public void addNode(int item) {  
        Node newNode = new Node(item);  
   
        if(head == null) {  
            head = tail = newNode;  
            head.prev = null;  
            tail.next = null;  
        }  
        else {  
            tail.next = newNode;  
            newNode.prev = tail;  
            tail = newNode;  
            tail.next = null;  
        }  
    }  
   
    public void printNodes() {  
        Node current = head;  
        if(head == null) {  
            return;  
        }  
        while(current != null) {  
            System.out.print(current.data + " ");  
            current = current.next;  
        }  
        System.out.println();
    }  
    
	void reverseList()
	{
		// Only constant amount of additional space
        Node temp = null;
        Node current = head;
        while (current != null) {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        }
        if (temp != null) {
            head = temp.prev;
        }
	}
	
}

public class Question2 {

    public static void main(String[] args) {  
    	DoubleLinkedList dl_List = new DoubleLinkedList();  
        dl_List.addNode(10);  
        dl_List.addNode(20);  
        dl_List.addNode(30);  
        dl_List.addNode(40);  
        dl_List.addNode(50);   
        dl_List.addNode(60);  
   
        System.out.print("The original double linked list: ");  
        dl_List.printNodes();  
        dl_List.reverseList();
        System.out.print("The reversed double linked list: ");  
        dl_List.printNodes();  
        
    }  
}
