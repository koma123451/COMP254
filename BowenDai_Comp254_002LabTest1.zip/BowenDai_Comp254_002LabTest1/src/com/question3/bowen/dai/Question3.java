package com.question3.bowen.dai;
//Bowen Dai(300775723)
public class Question3 {
	private  static final int  TEN = 10;
	public static int[] tenLargest(int arr[]){
		int tenlargest[]=new int[TEN];
		for (int i = 0; i<arr.length; i++) {
			for (int j=i+1; j<arr.length; j++) {
				if(arr[i]<arr[j]) {
					int temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		int i=0;
		while(i<10){
			tenlargest[i]=arr[i];
			i++;
		}
		return tenlargest;
	}
	public static void main(String[] args) {
		int arr[]={40,41,42,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
		int []tenLargest=tenLargest(arr);
		System.out.println("The ten largest elements in array are: ");
		for(int i=0;i<tenLargest.length;i++){
			System.out.print(tenLargest[i]+" ");
		}
	}
}
