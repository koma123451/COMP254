package com.question1.bowen.dai;

public class Question1 {

	public static int find_min(int[] a,int n)
	{
		if(n==1) {
			return a[0];
		}
		else {
			return Math.min(a[n-1],find_min(a,n-1));
		}
	}

	public static void main(String args[])
	{
		int[] a={5, 7, 9, 4, 2, 8, 1};
		System.out.println("Min element is "+ find_min(a,a.length));
	}
}
