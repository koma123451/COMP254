package com.exercise3.Bowen.Dai;

//Bowen Dai(300775723)

public class Question3 {

  public static int findMissingMumberFromArray(int[] nums)
  {
      int n = nums.length;
      int sum = ((n + 1) * (n + 2))/2;
      for(int i=0; i<n; i++)
        sum -= nums[i];
      return sum;
  }
  
  public static void main(String[] args)
  {
      int[] a = { 1, 2, 3, 14, 15, 11, 7, 8, 9, 10, 6, 13, 4, 5, 16 };
      System.out.println("The missing number in the array is " + findMissingMumberFromArray(a));
  }
}