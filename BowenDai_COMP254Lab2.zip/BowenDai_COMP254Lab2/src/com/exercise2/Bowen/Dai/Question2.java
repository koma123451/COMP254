package com.exercise2.Bowen.Dai;
//Bowen Dai(300775723)
import java.util.Random;

class PrefixAverage {

	/**
	 * Returns an array a such that, for all j, a[j] equals the average of x[0],
	 * ..., x[j]. A[j] = (X[0] + X[1] + � + X[j])/(j+1)
	 * 
	 ******************************************************/
	// inner loop size will be 1, 2, 3, ..., n (based on j=0,1,2,...,n-1)
	// we know that 1+2+3+...+ n-1+n = n(n+1)/2
	// so, the running time os O(n^2)
	public static double[] prefixAverage1(double[] x) {
		int n = x.length;
		double[] a = new double[n]; // filled with zeros by default
		for (int j = 0; j < n; j++) {
			double total = 0; // begin computing x[0] + ... + x[j]
			for (int i = 0; i <= j; i++)
				total += x[i];
			a[j] = total / (j + 1); // record the average
		}
		return a;
	}

	/**
	 * Returns an array a such that, for all j, a[j] equals the average of x[0],
	 * ..., x[j].
	 */
	// the running time is O(n)
	public static double[] prefixAverage2(double[] x) {
		int n = x.length;
		double[] a = new double[n]; // filled with zeros by default
		double total = 0; // compute prefix sum as x[0] + x[1] + ...
		for (int j = 0; j < n; j++) {
			total += x[j]; // update prefix sum to include x[j]
			a[j] = total / (j + 1); // compute average based on current sum
		}
		return a;
	}

	public static double[] fillArray(double[] array) {
		Random rand = new Random();
		for (int i = 0; i < array.length; i++) {
			array[i] = (double) rand.nextInt(100);
		}
		return array;
	}

	/**
	 * Tests the two versions of the 'repeat' algorithm, doubling the size of n each
	 * trial, beginning with the given start value. The first command line argument
	 * can be used to change the number of trials, and the second to adjust the
	 * start value.
	 */
	public static void main(String[] args) {

		long startTime = 0;
		long endTime = 0;
		long elapsed = 0;

	
		double[] arraySizeOf10     = new double[10];
		double[] arraySizeOf100    = new double[100];
		double[] arraySizeOf1000   = new double[1000];
		double[] arraySizeOf10000  = new double[10000];
		double[] arraySizeOf100000 = new double[100000];
		fillArray(arraySizeOf10);
		fillArray(arraySizeOf100);
		fillArray(arraySizeOf1000);
		fillArray(arraySizeOf10000);
		fillArray(arraySizeOf100000);
		
		double[][] doubleArray = {arraySizeOf10, arraySizeOf100, arraySizeOf1000, arraySizeOf10000, arraySizeOf100000 };
		
		
		String nString = "10";
		String spaces  = "      ";
		System.out.println("Experimental Analysis for prefixAverage1 (Elapsed in nanoseconds)");
		for (int i = 0; i<5; i++) {
			startTime = System.nanoTime();
			prefixAverage1(doubleArray[i]);
			endTime = System.nanoTime();
			elapsed = endTime - startTime;
			System.out.printf("n = %s %s  time: %d \n", nString, spaces,  elapsed);
			nString = nString + "0";
			spaces = spaces.substring(0, spaces.length()-1);
		}
		
	
		System.out.println("\nExperimental Analysis for prefixAverage2 (Elapsed in nanoseconds)");		
		nString = "10"; 
		spaces  = "      ";
		for (int i = 0; i<5; i++) {
			startTime = System.nanoTime();
			prefixAverage2(doubleArray[i]);
			endTime = System.nanoTime();
			elapsed = endTime - startTime;
			System.out.printf("n = %s %s  time: %d \n", nString, spaces,  elapsed);
			nString = nString + "0";
			spaces = spaces.substring(0, spaces.length()-1);
		}
	}

}