package com.exercise1.Bowen.Dai;


import maps.*;

//Driver class for Exercise 1
public class Question1 {
	public static void main(String[] args) {
		ChainHashMap<Integer, String> mapWithPointFiveLoad = new ChainHashMap<Integer, String>(10, 0.5);
		
		mapWithPointFiveLoad.put(1, "A");
		mapWithPointFiveLoad.put(2, "B");
		mapWithPointFiveLoad.put(3, "C");
		mapWithPointFiveLoad.put(4, "D");
		mapWithPointFiveLoad.put(5, "E");
		
		// print original values 
		System.out.println(" original values:");
		for(Entry<Integer, String> p : mapWithPointFiveLoad.entrySet()) {
			System.out.println(p.getKey() + " - " +p.getValue());
		}
		
		//  overwrite the original values
		mapWithPointFiveLoad.put(6, "F");
		mapWithPointFiveLoad.put(7, "G");
		mapWithPointFiveLoad.put(8, "H");
		mapWithPointFiveLoad.put(9, "I");
		mapWithPointFiveLoad.put(100, "J");
		
		// print the new values
		System.out.println(" new values:");
		for(Entry<Integer, String> p : mapWithPointFiveLoad.entrySet()) {
			System.out.println(p.getKey() + " - " +p.getValue());
		}
		
		// new key found, chain map will resize
		mapWithPointFiveLoad.put(11, "KKK");
		mapWithPointFiveLoad.put(12, "LLL");
		System.out.println(" new members:");
		for(Entry<Integer, String> p : mapWithPointFiveLoad.entrySet()) {
			System.out.println(p.getKey() + " - " +p.getValue());
		}
		
		
	}
}
