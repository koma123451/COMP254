package com.exercise2.Bowen.Dai;

import maps.UnsortedTableMap;

public class Question2 {
	public static void main(String[] args) {
		UnsortedTableMap<String, String> aMap = new UnsortedTableMap<>();
		
		// Populate Map
		aMap.put("Lakers", "Lebron James");
		aMap.put("Nets", "Kevin Durant");
		aMap.put("76ers", "James Harden");
		aMap.put("Golden States", "Steph Curry");
		
		// Test containsKey
		System.out.println("containsKey of ('Lakers'): " + aMap.containsKey("Lakers"));
		System.out.println("containsKey of ('Golden States'): " + aMap.containsKey("Golden States"));
		
		// null key
		System.out.println("containsKey of ('Kobe Bryant'): " + aMap.containsKey("Kobe Bryant"));
	}
}
