package com.exercise2.bowen.dai;

import com.example.bowen.dai.*;

public class Question2 {
	/** Prints parenthesized representation of subtree of T rooted at p. */
	public static <E> void parenthesize(Tree<E> T, Position<E> p) {
		System.out.print(p.getElement());
		if (T.isInternal(p)) {
			boolean firstTime = true;
			for (Position<E> c : T.children(p)) {
				System.out.print( (firstTime ? " (" : ", ") ); 
				firstTime = false;                             
				parenthesize(T, c);                           
			}
			System.out.print(")");
		}
	}

	public static void main(String[] args)
	{
		
		LinkedBinaryTree lbt = new LinkedBinaryTree();
		Position<String> A = lbt.addRoot("A");

		Position<String> B = lbt.addLeft(A, "B");
		Position<String> D = lbt.addRight(A, "D");

	
		Position<String> E = lbt.addLeft(B, "E");
		Position<String> F = lbt.addRight(B, "F");

	
		Position<String> G = lbt.addLeft(F, "G");
		Position<String> H = lbt.addRight(F, "H");

		
		Position<String> C = lbt.addLeft(D, "C");
		Position<String> J = lbt.addRight(D, "J");

		parenthesize(lbt, A);
		

		System.out.println("");
		printPostOrderWithHeight(lbt);
	}

	// exercise 2
	public static <E> void printPostOrderWithHeight(AbstractTree<E> T) {
		for (Position<E> p : T.postorder()) {
			System.out.println("Element: " + p.getElement() + "[Height = " + T.height(p) + "]");
		}
	}
}
