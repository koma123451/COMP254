package com.exercise1.bowen.dai;

import java.util.ArrayList;

import com.example.bowen.dai.AbstractBinaryTree;
import com.example.bowen.dai.AbstractTree;
import com.example.bowen.dai.LinkedBinaryTree;
import com.example.bowen.dai.Position;
import com.example.bowen.dai.Tree;


public class Question1 {
	/** Returns a string containing n spaces. */

	public static <E> void printPreorder(AbstractTree<E> T) {
		for (Position<E> p : T.preorder())
			System.out.println(p.getElement());
	}

	public static <E> void printPostOrder(AbstractTree<E> T) {
		for (Position<E> p : T.postorder())
			System.out.println(p.getElement());
	}

	public static <E> void printInOrder(AbstractBinaryTree<E> T) {
		for (Position<E> p : T.inorder())
			System.out.println(p.getElement());
	}

	/** Prints parenthesized representation of subtree of T rooted at p. */
	public static <E> void parenthesize(Tree<E> T, Position<E> p) {
		System.out.print(p.getElement());
		if (T.isInternal(p)) {
			boolean firstTime = true;
			for (Position<E> c : T.children(p)) {
				System.out.print( (firstTime ? " (" : ", ") ); 
				firstTime = false;                             
				parenthesize(T, c);                            
			}
			System.out.print(")");
		}
	}

	public static void main(String[] args)
	{
		
		LinkedBinaryTree lbt = new LinkedBinaryTree();
		Position<String> A = lbt.addRoot("A");

		
		Position<String> B = lbt.addLeft(A, "B");
		Position<String> D = lbt.addRight(A, "D");

	
		Position<String> E = lbt.addLeft(B, "E");
		Position<String> F = lbt.addRight(B, "F");

	
		Position<String> G = lbt.addLeft(F, "G");
		Position<String> H = lbt.addRight(F, "H");

		
		Position<String> C = lbt.addLeft(D, "C");
		Position<String> J = lbt.addRight(D, "J");

		parenthesize(lbt, A);
		
		System.out.println("In Order of tree:");
		printInOrder(lbt);
		
		Position<String> inOrderNextB = lbt.inorderNext(B);
		if (inOrderNextB != null) {
			System.out.println("inorder next of B: " + inOrderNextB.getElement()); 
		} else {
			System.out.println("inorder next of B: null, this is the last node");
		}
		
		Position<String> inOrderNextH = lbt.inorderNext(H);
		if (inOrderNextH != null) {
			System.out.println("inorder next of H: " + inOrderNextH.getElement()); 
		} else {
			System.out.println("inorder next of H: null, this is the last node");
		}
		
		Position<String> inOrderNextF = lbt.inorderNext(F);
		if (inOrderNextF != null) {
			System.out.println("inorder next of F: " + inOrderNextF.getElement()); 
		} else {
			System.out.println("inorder next of F: null, this is the last node");
		}
		
		Position<String> inOrderNextJ = lbt.inorderNext(J);
		if (inOrderNextJ != null) {
			System.out.println("inorder next of J: " + inOrderNextJ.getElement()); 
		} else {
			System.out.println("inorder next of J: null, this is the last node");
		}
		
		System.out.println("Post Order of tree:");
		printPostOrder(lbt);
		
		Position<String> postOrderNextE = lbt.postorderNext(E);
		if (postOrderNextE != null) {
			System.out.println("postorder next of E: " + postOrderNextE.getElement()); 
		} else {
			System.out.println("postorder next of E: null, this is the last node");
		}
		
		Position<String> postOrderNextC = lbt.postorderNext(C);
		if (postOrderNextC != null) {
			System.out.println("postorder next of C: " + postOrderNextC.getElement()); 
		} else {
			System.out.println("postorder next of C: null, this is the last node");
		}
		
		
		Position<String> postOrderNextA = lbt.postorderNext(A);
		if (postOrderNextA != null) {
			System.out.println("postorder next of A: " + postOrderNextA.getElement()); 
		} else {
			System.out.println("postorder next of A: null, this is the last node");
		}

	
	}
}
