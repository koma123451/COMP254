package com.exercise1.Bowen.Dai;
//Bowen Dai(300775723)
import java.util.Scanner;
public class Exercise1 {
	      
      public static void main (String[] args)
      {
          Scanner sc = new Scanner(System.in);
          System.out.print("Enter positive number 1: ");
          int n1 = sc.nextInt();
          System.out.print("Enter positive number 2: ");
          int n2 = sc.nextInt();

          System.out.println("Product of " + n1 + " and " + n2 + ": " + productOf2PositiveNum(n1, n2));
      }
      public static int productOf2PositiveNum(int n1, int n2)
      {
         
          if(n2 != 0) {
             
              return (n1 + productOf2PositiveNum(n1, n2 - 1));
          }else {
              return 0;
          }
      }

}
