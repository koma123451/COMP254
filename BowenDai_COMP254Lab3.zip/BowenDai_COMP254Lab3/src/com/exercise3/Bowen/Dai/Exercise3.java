package com.exercise3.Bowen.Dai;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
//Bowen Dai(300775723)
public class Exercise3 {
	public static void main(String[] args) 
	{
	System.out.println("Enter a String: ");	
	Scanner input=new Scanner(System.in);
	String str=input.nextLine();
	
	 System.out.println(areMoreVowels(str,0,0));
	}
	public static boolean areMoreVowels(String str,int c,int v) {
		
		String vowels="aeiou";
		if(vowels.indexOf(str.charAt(0))>=0) {
			v++;
		}else {
			c++;
		}
		if(str.length()==1) {
			return v>c;
		}
		return areMoreVowels(str.substring(1),c,v);
	}

//public static int VowelOrConsonants(String str) 
//{
	//str=str.toLowerCase();
	//int v=0;
//	int co=0;
	//char c;
	//if(str.length()<1) {
	//	return 0;
//	}
//	else {
	//	c=str.charAt(0);
	//	if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u') {
    //      v++;
     //     }
	//	else {co++;}}
	//    if(v>co)
		//return v+VowelOrConsonants(str.substring(1));
	    
	    	
	 //   else 
	   // 	return co+VowelOrConsonants(str.substring(1));
		
	
	
	

}


